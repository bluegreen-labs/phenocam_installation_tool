#!/bin/sh

echo "trying image acq" >> /var/tmp/log.txt

debugmode="yes"
loopaddr="admin:phen0cam@127.0.0.1"

cd /var/tmp

i2cset -yf 0 0x21 0x20 1 #buffer sequential bytes of EXIF info. 
swl=`i2cget -yf 0 0x21 0x20` #low exposure (shut width)
echo $swl >> /var/tmp/log.txt

tempdir=/var/tmp  #our temporary working folder.
mkdir -p $tempdir #This folder likely exists, but make sure.
cd $tempdir       #use the dram, don't wear out flash. /var/tmp most space

getEXIF()
{
 i2cset -yf 0 0x21 0x20 1 #buffer sequential bytes of EXIF info. 
 swl=`i2cget -yf 0 0x21 0x20 | cut -b3-4` #low exposure (shut width)
 swh=`i2cget -yf 0 0x21 0x20` #high exposure number of rows
 shutwidth=$swh$swl #Full exposure in ascii hex (e.g. 0x0464)
 rpsl=`i2cget -yf 0 0x21 0x20 | cut -b3-4` #low
 rpsh=`i2cget -yf 0 0x21 0x20` #high 
 rowspersec=$rpsh$rpsl #rows per second in ascii hex (e.g. 0x83D6)
 bll=`i2cget -yf 0 0x21 0x20 | cut -b3-4` #low black level
 blh=`i2cget -yf 0 0x21 0x20` #high 
 blacklev=$blh$bll #blacklevel (pedestal e.g. 0x0048)
}

#Shows EXIF info, after it's gathered. Only in debugmode=yes.
showEXIF()
{
if [ $debugmode = "yes" ]; then
 echo Shutter width ${shutwidth} >> /var/tmp/log.txt
 echo Rows per second ${rowspersec} >> /var/tmp/log.txt
 echo Black level ${blacklev} >> /var/tmp/log.txt
fi
}

#Capture a raw dump (It's not a DNG yet). 
# Returns $rawname= file made, or "none"

getDUMP()
{ 
 echo vcap0_0_0_2 o $tempdir > /proc/videograph/gs/dump #make raw pic
 datetimestring=`date +"%Y_%m_%d_%H%M%S"`
 for i in 1 2 3 #if it goes over 3 secs, abort!
 do
  sleep 1s  #1s should do it for dump, most of the time.
  dumpfile=`ls vcap0_0_0_2* 2>/dev/null`  
  if [ -z "$dumpfile" ]
  then
   echo Extra sleep needed for vcap.
   rawname="none"
  else
   rawname=mycamera_${datetimestring}.dng
   mv $dumpfile $rawname  
   break
  fi
 done
}

find . -name vb.htm* -delete  #cleanup...
wget http://$loopaddr/vb.htm?textenable1
overlaystate=`cat vb.htm?textenable1 | grep -o '.\{1\}$'`
find . -name vb.htm* -delete  #wget fetches it into a file...
wget http://$loopaddr/vb.htm?EnableTextForRaw=0 #off
find . -name "vb.*" -delete
sleep 3 #overlay seems to go off in < 2 sec. Play it safe.

#Start of script to upload 2 images, one with IR closed, one open.
#First clean oldd files, save IR state, make open and closed values
find . -name "vcap0_0_0_2*" -delete #delete leftovers
oldreg7=`i2cget -yf 0 0x21 7` #save IR reg contents
irclose=`echo $oldreg7 | sed s/./0/3` #Replace top nibble with IR closed 
iropen=`echo $oldreg7 | sed s/./1/3` #Replace top nibble with IR open bits

echo $oldreg7 >> /var/tmp/log.txt
echo $irclose >> /var/tmp/log.txt
echo $iropen >> /var/tmp/log.txt

#Close IR so it can settle before we lock exposure with raw mode.
i2cset -yf 0 0x21 7 $irclose #IR closed
sleep 1s #needs time to close and adjust exposure. 
#raw mode increases H.264 size and we need time to expand buffers
#if it's the first time this ran. 
i2cset -yf 0 0x21 0x1F 1 #trigger raw mode, lock exposure
sleep 1s #let take effect for sure, might be a few pics

#grab EXIF info for these pics.  shutwdth,exprows wont change. blklv can. 
getEXIF
showEXIF
getDUMP

if [ $rawname = "none" ]; then
 echo FAILED to make first raw picture! >> /var/tmp/log.txt
 exit 1 #oops. didnt make first pic.
fi

echo First raw picture! >> /var/tmp/log.txt
#ftpput $vb -u anonymous -p "anonymous"  ${uploadfolder}/${rawname} ${rawname}
rm ${rawname}

