#!/bin/sh
#Script to capture a raw image for NetCamSCI science camera.
#It also adds EXIF headers to make a DNG file format (a tiff file) with
#embedded information that can be read by MatLab.  It does 
#NOT control the IR mechanism, you must do that externally.

#You must specify whether to enter and/or leave raw mode when running this.
#What this means is, the camera runs in jpeg mode most of the time.
#To capture raw images, this function must activate raw mode and
#wait a couple of seconds. Since pictures are normally taken in 
#sets of 2 (non-IR + IR), it's best to take the first while specifying to enter
#raw mode but not leave it, and take the second specifying to leave
#raw mode, but not enter it. 

#The date/time portion of the image has the current date/time, which could be an
#issue if you are pairing images and want the same date/time.  You will need
#to account for that, keeping in mind there's precise information in the dng data,
#and you could stick your pairing information into one of the user fields.

#Entry parameters: capture_dng.sh startraw stopraw username userpass camera_name
#You also need the files listed later, or the defaults will be used.

#startraw and stopraw = 0 not to do that, 1 to do that. Typically first pic
#has 1 0 to start raw mode before the picture, but not end it, 
#and second (IR) pic has 0 1, to stop raw mode at the end.

#username, userpass = for log into camera to run API. 
#Typically admin + password from bottom of camera label.

#camera_name =  Typically mycamera_ or mycamera_IR_ (Datetimestring is
#  appended to the end for final file name, so a trailing _ is a good idea))

#Exit codes:
#0=success (pic is in /var/tmp). $DNG_NAME has the name of the file produced.
#1=incorrect input parameters
#2=ftpput failed, will echo ftpput error code before exiting script.

#set -x          #Set to show line #s. Comment out for normal.

#Product names. Can't be too long or won't fit in alloted xif tag data area.

cammodel="CAM-SCI2IR" #(10) 15 max
companyname="StarDot Technologies" #(20) 23 max
camname="NetCamSCI" #(9) max is size of companyname plus camname + 2 <= 32.

#Names of files used to fill in the fields. Each specifies full path, but
#it's likely they're all in the same place. Here's some defaults for testing
#(one with, one without lf):
# echo "Author field "'('$authorfile')'" is not filled in." > $authorfile
# echo -n "Image description "'('$descriptionfile')'" is not filled in." > $descriptionfile
authorfile="/mnt/cfg1/rawmode/author" #143 ascii chars max
descriptionfile="/mnt/cfg1/rawmode/description" #143 ascii chars max

#Weather is in StarDot Weather station format: t=301.0 h=64 b=1013
#Temperature in degrees Kelvin, humidity relative %, baro in millibars.
# echo -n "t=301.0 h=64 b=1013" > $weatherfile
weatherfile="/mnt/cfg1/rawmode/weatherinfo"

#gpsinfo is in the format of a GPGGA string. It can be filled manually or read from a USB dongle.
#default is stardot: lat 33°51'28.26'' N, long. 118°0'56.5308'' W. Altitude 23m. Direction 77° 
#Google says we're at +33.87 and -118.00 (- is west).  
#echo -n -e "\$GPGGA,,3351.471,N,11800.94218,W,,,,23.0,M,,,,0*00" > $gpsinfo
gpsinfo="/mnt/cfg1/rawmode/GxGGA_str"

#Direction info is not in the GPS string. Default file is stardot direction. 
#echo -n "M,77" > $camdir #where T=true north, or M=magnetic north.
camdir="/mnt/cfg1/rawmode/camdir"

scriptname=${0##*/} #name of this script for error msg use

#A function to add N nulls to output file $rawname. 0 is ok, limit is huge.
addnulls()	#addnulls $nullcnt.  
{
 nullcnt=0
 while [ $nullcnt -lt $1 ]; do
  echo -n -e \\x00 >> $rawname #Note: Our ash shell doesn't support octal here.
  nullcnt=$((nullcnt+1))
 done
}

#This function fills in a 144 (0x90) text field value at the end of
#file $rawname. That max length includes a trailing null. 
#If the string passed in inputfile is bigger than 143 chars, it'll be
#cropped. If the file doesn't exist, the default will be used.  
#There's no error checking on the default, don't exceed 143.
#Unused portions are filled with nulls to meet the 144 size.
#On return, $fieldlen has the actual field's text length with null.

fillfield() # fillfield "default text" inputfile
{
 if [ -e $2 ]; then

  fieldlen=`wc -c "$2" | awk '{print $1}'` #wc makes 2 cols, awk gets 1st
  if [ $fieldlen -gt 143 ]; then
   echo File $2 exists but is too long. Cropping...
   fieldlen=143
  fi
  if [ $fieldlen -ne 0 ]; then
   cat $2 | head -c$fieldlen >> $rawname
  fi
  
 else #no file, use default.
 
  echo File $2 does not exist, using default.
  fieldlen=`echo -n $1 | wc -c` #need -n or it'll count the newline
  echo -n $1 >> $rawname 
  
 fi

 echo -n -e \\x0 >> $rawname	#Both strings need null terminate ala EXIF.
 fieldlen=$((fieldlen+1))
 i=$fieldlen
 while [ "$i" -lt 144 ]; do
  echo -n -e \\x0 >> $rawname
  i=$((i+1))
 done
}

#Takes a max 32 bit (signed if you exceed 31 bits) integer and expands it into 4 escaped bytes
#which represent that value, intel order (low byte first). It's compatible
#with the echo -n -e command for appending to our file's end. 
#Example: numval=128; expand_4B $numval = "\\x80\\x00\\x00\\x00"
expand_4B()
{
wnum=`awk -v foo=${1} 'BEGIN { printf "%08X", foo }'` #negative vals print as 16 digits with ordinary printf.
expandedlen='\\x'`echo -n $wnum | cut -c7-8`'\\x'`echo -n $wnum | cut -c5-6`'\\x'`echo -n $wnum | cut -c3-4`'\\x'`echo -n $wnum | cut -c1-2`
echo -n -e $expandedlen
}

#Takes a max 16 bit value and expands it into 2 escaped bytes (used for an IFD tag count).
#Example: numval=128; expand_2B $numval = "\\x80\\x00"
expand_2B()
{
wnum=`awk -v foo=${1} 'BEGIN { printf "%04X", foo }'`
expandedlen='\\x'`echo -n $wnum | cut -c3-4`'\\x'`echo -n $wnum | cut -c1-2`
echo -n -e $expandedlen
}

#Outputs 1 unsigned "real number" to file $rawname. Intended for longitude and lat, it 
#produces the  precision according to what you enable here. 3 meters is current
#the best civilian GPS will do. 1 second = 30.7 meters. Some locations might be manual.
#100 is likely the "honest" precision, but it doesn't look good as accurate seconds
#if you don't take into account the reality, so we use 10X that.

#gpsprecision="10" #3 meters precision if only GPS input
#gpsprecision="100" #.3 meters precision 
gpsprecision="1000" #Misleading precision, but looks better mathmatically.
gpsrealnum() #gpsrealnum $yournum
{
 ournum=`awk "BEGIN{print $1 * $gpsprecision}"`
 ournum=`printf "%.0f" $ournum 2> /dev/null`
 echo -n -e `expand_4B $ournum ; expand_4B $gpsprecision` >> $rawname
}

#Outputs 1 signed or unsigned "real number" to file $rawname with .01 accuracy.  
#The signed or unsigned part of real numbers only has to do with bit 31. This produces
#the correct RATIONAL or SRATIONAL in any case. Precision suitable for weather info.
wxprecision="100" 
weathernum() #weathernum $yournum (signed decimal like -30.76)
{
 ournum=`awk "BEGIN{print $1 * $wxprecision}"` #Bump up a couple of decimal places
 ournum=`printf "%.0f" $ournum 2> /dev/null` 	#Crop unused decimal places
 echo -n -e `expand_4B $ournum ; expand_4B $wxprecision` >> $rawname #make a RATIONAL number.
}


#Expands a nautical standard location format (longitude or lattitude) into
#$ldeg, $lmin, $lsec, with seconds allowing fractional values.
#Entry value is Degrees*100 + minutes + seconds/60

expandloc() # expandloc $ourloc 
{
 ldeg=`awk "BEGIN{print $1 / 100}"`
 ldeg=`echo "${ldeg%%.*}"` #crop decimals, no round
 lrem=`awk "BEGIN{print $1-($ldeg*100)}"`
 lmin=`echo "${lrem%%.*}"`
 lsec=`awk "BEGIN{print $lrem-$lmin}"`
 lsec=`awk "BEGIN{print $lsec*60}"`
 }
 
#Checks for 1 and only one char in specified variable. 
#echos result. If none specified, echoes "X".
refcheck() #gltrf=`refcheck $gltrf`
{
 echo -n ${1}'X' | cut -c1 #make sure we get at least 1.
}

#This function takes an offset of an IFD tag list, and calculates the next offset. 
#So it can skip from IFD 0 to the exif tags start.
#Use: nextifd $ifd0start $tagcnt

nextifd()
{
newoff=$(($2*12)) #12 per tag
newoff=$((newoff+$1)) #add to current ifd offset
newoff=$((newoff+6)) #2 for count of tags, 4 to terminate that list
echo $newoff
}

#Debug function.  Shows current location in the output file.
#Output:  $tagname is located at 0xNNNN

whereami() #whereami $tagname
{
sync 
outloc=`stat -c %s $rawname` #file size
outloc=`printf "0x%X" $outloc`
echo $1 is located at $outloc
}

#End of functions
 
tempdir=/var/tmp  #Best temporary working folder in the rawmode camera
mkdir -p $tempdir #This folder almost certainly exists, but make sure.
cd $tempdir       #In here we use ram. Other folders could wear out flash.

# feedback on input parameters

if [ "$#" -ge 1 ]; then  #Have a parameter?
 cut1=`echo $1 | cut -b1-2` #first 2 chars of first argument.
 if [[ $cut1 == "-h" ]]; then
  echo "Usage is: $scriptname startraw stopraw username userpass camera_name"
  exit 1
 fi
fi

if [ "$#" -ne "5" ]; then
 echo "$scriptname: Error, illegal number of parameters."
 exit 1
fi

startraw=$1
stopraw=$2
username=$3
userpass=$4
camera_name=$5

if ( ( [ $startraw != "0" ] && [ $startraw != "1" ] ) || ( [ $stopraw != "0" ] && [ $stopraw != "1" ] ) ); then
 echo "$scriptname: Error, illegal raw mode start or stop specification."
 exit 1
fi

#our camera "API" consists of web page requests. Fortunately loopback addr works.
#The main negative with this API is that we currently use wget, which always treats
#the results like a file and writes it to our temp folder.

loopaddr="$username:$userpass@127.0.0.1" # "admin:overseer@127.0.0.1"

#If "start" was specified, go into raw mode and turn the overlay off.
#Command for raw mode is inside fpga register. The first time you 
#go into raw mode, you need to delay 4 seconds because the operating
#system finds the H.264 buffers inadequate for the raw images. After
#that you could reduce to 2 secs, but it's not worth the added
#complexity.  The commands used to control the overlay on/off are 
#special API calls; they dont save to config flash and wear it out.
#API= http://user:pass@127.0.0.1/vb.htm?EnableTextForRaw=0

#Note: if you go to that web page link using a browser, a line of 
#0,  0   and 0 are output on the console.  So the script causes it also,
#but it's the command itself in the camera.

if [ $startraw -eq "1" ]; then
 echo Entering raw mode...
 i2cset -y -f 0 0x21 0x1F 1 #trigger raw mode, lock exposure
 find . -name vb.htm* -delete #clean up possible leftovers: wget won't overwrite.
 wget http://${loopaddr}/vb.htm?EnableTextForRaw=0 #Overlay off. Note: causes output on concole of 0, 0 and 0 on console.
 find . -name "vb.*" -delete
 sleep 4 #overlay goes off in < 2 sec, but raw mode causes need for buffer increases, so wait.
fi

#grab EXIF info for these pics.  shutwdth,exprows wont change. 
#blklv can and will when the IR is opened.
i2cset -y -f 0 0x21 0x20 1 #buffer sequential bytes of EXIF info. 
swl=x`i2cget -y -f 0 0x21 0x20 | cut -b3-4 | head -c2` #low exp(shut width)
swh=x`i2cget -y -f 0 0x21 0x20 | cut -b3-4 | head -c2` #high exp (0x0464)
rpsl=x`i2cget -y -f 0 0x21 0x20 | cut -b3-4 | head -c2` #low
rpsh=x`i2cget -y -f 0 0x21 0x20 | cut -b3-4 | head -c2` #high (0x83D6)
bll=x`i2cget -y -f 0 0x21 0x20 | cut -b3-4 | head -c2` #low black level
blh=x`i2cget -y -f 0 0x21 0x20 | cut -b3-4 | head -c2` #high (0x0048)

#Now make that pic. We have to use a program to do it if we're not root,
#because the actual capture requires super user permissions. That program will set up  
#permissions before capturing the raw image. If you've managed to change 
#the root password, this version will fail.  You need to pass it to this script
#and embed it in the getraw command: getraw root_password capture_folder
#getraw /var/tmp   < This script has no provision for changing permissions, so just pass path.

#However, if you are doing this as root, you must NOT use that program. In that case,
#you use the vcap program to do it:
#echo vcap0_0_0_2 o /var/tmp > /proc/videograph/gs/dump #make raw pic

rm -f /var/tmp/vcap* #clean up in case of interrupted script.
ouruser=`whoami 2>/dev/null`X #can get "" for answer to whoami
if [[ $ouruser == "rootX" ]]; then
 echo vcap0_0_0_2 o /var/tmp > /proc/videograph/gs/dump #make raw pic directly if root user
else
 getraw /var/tmp   #Either way of getting the pic can take a while, but the script resumes!
fi
datetimestring=`date +"%Y_%m_%d_%H%M%S"`

#We have to wait here, but while we do, let's find out of the net is up so we don't 
#lose time later. 
for i in 1 2 3 #So must wait, but if it takes over 3, abort!
 do
  sleep 1s  #1 sec should do it for dump, most of the time.
  dumpfile=`ls vcap0_0_0_2* 2>/dev/null`  
  if [ -z "$dumpfile" ]; then
   rawname="none"
   echo Had to delay 1 more second to get a raw file...
  else
   rawname=${camera_name}${datetimestring}.dng
   break
  fi
 done
 
if [ $rawname = "none" ]; then
 echo "$scriptname: Error, failed to capture raw image!"
 exit 1 #oops. Maybe BT.1120 is down... Could diagnose here.
fi

#If "stop" was specified, exit raw mode and restore overlay state

if [ $stopraw -eq "1" ]; then
 echo Exiting raw mode...
 i2cset -y -f 0 0x21 0x1F 2 #exit raw mode, free up visual images mode and exposure.
 wget http://${loopaddr}/vb.htm?textenable1
 overlaystate=`cat vb.htm?textenable1 | grep -o '.\{1\}$'` #Get config's overlay state
 find . -name vb.htm* -delete  
 wget http://$loopaddr/vb.htm?EnableTextForRaw=$overlaystate #Set it, without flash write.
 find . -name "vb.*" -delete
fi

#Patch the exif headers into an output file. We'll dump the raw image after that.

#Our offsets are calculated from what you put here, EXCEPT for the empty space into which
#we put data larger than 4 bytes. That's the amount you could fit in an EXIF "tag", and if 
#you can't you put a 4 byte pointer to this area.  We allocate a certain amount of that
#extra data by simply moving IFD 0's start. 

#If you want to add a new tag that won't fit, just increase ifd0start. 
#*4 minimum alignment might be wise? 

#If you want to add a tag that does fit, put it in the appropriate area (ifd 0, exif, or gps tag areas).
#Place it in numeric order by tag id, which will put it after the count, and before the end marker.
#Then increment the appropriate tag count below this.  To see a list of supported MatLab tiff tags,
#use command tiff.getTagNames at the MatLab prompt.  Unsupported tags either show up in a separate
#area of the "answer", or they might not show up at all.  Use exiftool(-k).exe to see those.

ifd0start="1024" #Where IFD0 starts, and thus how much extra data you can put up to that point
ifdtags=41 #These 3 must be modified if you change the number of tags in one of these areas.
exiftags=5 #exif tags are considered different from the ones in ifd 0 by specification
gpstags=9 #gps tags get a different area also.

#These autocalculate and are embedded in the ifd 0 tags.
exifstart=`nextifd $ifd0start $ifdtags`
gpsstart=`nextifd $exifstart $exiftags`
stripoffsets=`nextifd $gpsstart $gpstags`

#Now the actual output file start, which is what holds the stuff that makes it a legal dng (tiff) file.
#The pic comes after it all. It starts with a fixed set of 8 bytes (except ifd0start can move).

echo -n II > $rawname #Offset 0: Intel's little indian format
echo -n -e \\x2a\\x0 >> $rawname #TIFF version 2A (always same)
echo -n -e `expand_4B $ifd0start` >> $rawname #IFD 0 location (tiff tags specifying the values).

#Now the user data area. We've left enough space to the IFD that
#we can put all the tag data larger than 4 bytes. 

#Offset 8: Manufacturer string, null terminated. 24 chars allowed here.
#We keep the next 3 sizes for storing in the exif tags. Need len + location there.
echo -n -e ${companyname}\\x0 >> $rawname
companysize=$((${#companyname}+1)) #+1 is for the terminating null
addnulls $((24-$companysize))

#Offset 0x20: Model = "CAM-PH2IR",0 . 16 chars total here
echo -n -e ${cammodel}\\x0 >> $rawname
modelsize=$((${#cammodel}+1))
addnulls $((16-$modelsize))

#Offset 0x30: UniqueCameraModel "StarDot Technologies NetCamPH",0
echo -n -e ${companyname}' '${camname}\\x0 >> $rawname
uniquesize=$((${#companyname}+${#camname}+2))
addnulls $((32-$uniquesize))

#Offset 0x50: DateTime  YYYY:MM:DD HH:MM:SS
#We already got the date for the file name, but it was
#a slightly different format: 2017_05_17_175758  
echo -n $datetimestring | sed 's/_/:/g' | head -c10 >> $rawname
echo -n -e \\x20 >> $rawname
echo $datetimestring | cut -b 12-13 | head -c2 >> $rawname
echo -n -e \\x3A >> $rawname
echo $datetimestring | cut -b 14-15 | head -c2 >> $rawname
echo -n -e \\x3A >> $rawname
echo $datetimestring | cut -b 16-17 | head -c2 >> $rawname
addnulls 13

#Offset 0x70: True exposure time is in sensor rows, not seconds. 
#But we can convert to get best accuracy. We gathered that info
#earlier. Format is a 32 bit "rational" number, which is dw[0]/dw[1],
#or shutwidth[32]/rowspersec[32]. Then we pad to 16 bytes (extra unused)
#0x64,4,0,0, 0xd6,0x83,0,0, 0,0,0,0, 0,0,0,0,       
echo -n -e \\${swl}\\${swh}\\x0\\x0 >> $rawname #each is format xNN
echo -n -e  \\${rpsl}\\${rpsh}\\x0\\x0 >> $rawname
addnulls 8

#Offset 0x80: software name. Max length we can have here is 47 chars plus null.
softwarename="StarDot RAW-to-DNG converter V01.00.00"
echo -n -e $softwarename\\x0 >> $rawname
snamelen=${#softwarename}
snamelen=$((snamelen+1)) #length with the null. 
sfill=$((48-snamelen))	
addnulls $sfill

#Offset 0xB0: CameraSerialNumber (mac address). "0030f43a0000",0,0,0,0
cat /sys/class/net/eth0/address | sed 's/://g' | head -c12 >> $rawname
addnulls 4

#We embedded pixel size of the sensor here and set ResolutionUnit = CM later on.
#These are defined as the number of pixels per res unit.  
#5.04 microns gives 1cm=10000uM/5.04 = 1984.1 = 0x7C0
echo -n -e \\xC0\\x7\\x0\\x0\\x1\\x0\\x0\\x0 >> $rawname #C0=XResolution
echo -n -e \\xC0\\x7\\x0\\x0\\x1\\x0\\x0\\x0 >> $rawname #C8=YResolution

#Noise levels, real number of 4.
echo -n -e \\x4\\x0\\x0\\x0\\x1\\x0\\x0\\x0 >> $rawname #D0=BaselineNoise

#Offset 0xD8: Unused, 24 bytes.
addnulls 24

#Offset 0xF0: EXIF info CFGPattern, 0xF8: EXIF info ActiveARea.
#Active area: 0,0,1080,1920
echo -n -e \\x2\\x0\\x2\\x0\\x0\\x1\\x1\\x2 >> $rawname #0xF0 2x2,R=0,G1,G1,B2
echo -n -e \\x0\\x0\\x0\\x0\\x38\\x4\\x80\\x7 >> $rawname #0xF8 Y,X,height,width.

#Offset 0x100: Artist (author/scientist). We pad to 144 chars (0x90),
#but this string is limited to 143 text chars so we can null terminate it.
fillfield "Image author unknown" $authorfile 
authorlen=$fieldlen #embed in IFD

#Offset 0x190: Image description (for example, location). Same kind of field.
fillfield "No description entered" $descriptionfile 
descriptionlen=$fieldlen #embed in IFD

#Offset 0x220: GPS longitude, lattitude, altitude (all in $gpsinfo file), direction ($camdir file). 
#Stardot coordinates are the defaults in the GPS file, otherwise it's in a file as $GPGGA string.  
#If no file is found, all are set to 0, N, and W. Direction is in a separate file.

#The sign is not always consistant (E and W). Best to convert to unsigned,
#and specify the N/S and W/E values. We assume if longitude is negative, it's South (always true)
#For latitude, we assume west is negative (nearly always true). 

#These are "rational numbers".  Result is 1st dword / 2nd dword, signed values. We used only + values.

#The National Marine Electronics Association (NMEA) has developed a GPS spec that is
#in wide usage, including garmin devices. http://gpsworld.com/what-exactly-is-gps-nmea-data/
#But the best docs for this are at http://aprs.gids.nl/nmea/#gga


#lat 33° 51' 28.26'' N, long. 118° 0' 56.5308'' W. Altitude 23m. Direction 90°
#Google says we're at +33.87 and -118.00 (- is west).  

#We support only the popular $G?GGA Geographic Position message because it contains all the info we need.
#It's first 2 chars identify the source: GP=(global position, USA), GL=GLOSNAS(russia), GB=BDS(chinese), GN=multiple
# * indicates of interest to us (except for *c checksum):
#$GPGGA,hhmmss.ss,*llll.ll,*a,*yyyyy.yy,*A,q,ss,h.h,*a.a,M,g.g,M,x.x,xxxx*c  (15 fields if xxxx*c is last)
#$GLGGA,062335.000,2446.4233,N,12100.4403,E,1,01,0.9,121.7,M,15.0,M,,0000*4B
#hhmmss.ss = UTC of position 
#llll.ll = latitude of position. Degrees*100 + minutes + seconds/60
#a = N or S
#yyyyy.yy = Longitude of position. Degrees*100 + minutes + seconds/60
#A = E or W 
#q = GPS Quality indicator (0=no fix, 1=GPS fix, 2=Dif. GPS fix) 
#ss = number of satellites in use 
#h.h = horizontal dilution of precision 
#a.a = Antenna altitude above mean-sea-level
#M = units of antenna altitude, meters 
#g.g = Geoidal separation
#M = units of geoidal separation, meters 
#x.x = Age of Differential GPS data (seconds). CAN BE BLANK!
#xxxx = Differential reference station ID 
#*c = checksum

#There's also $GPRMC and $GPGLL but they are info about moving and do not contain altitude,
#and $PGRMZ which is only altitude.

#NOTE: All info other than the used $GPGGA info is ignored, so a script making it can fill unused with anything.
#For example, we don't pay attention to the time, except to pass it and get the data we need. And a GLONASS
#example we found had a blank x.x age of differential (,, to indicate it's blank).

#Receivers: Generic on Amazon.com:  u-blox GNSS receiver
#https://www.amazon.com/Receiver-Antenna-Gmouse-Laptop-Navigation/dp/B073P3Y48Q/ref=sr_1_2?ie=UTF8&qid=1500931146&sr=8-2-spons&keywords=GPS+usb&psc=1
#U-BLOX 7 Chipset inside, USB Port. (Datasheet is GPS_u-blox7-V14.pdf)

gpsfound=0
if [ -f $gpsinfo ]; then
 IFS="," #field separator
 read gid gtime glat gltrf glon glnrf gqual gsats gdil galt garf grest < $gpsinfo
# echo $gid $gtime $glat $gltrf $glon $glnrf p $gqual q $gsats r $gdil s $galt t $garf u $grest xxx
 if [[ $gid == '$GPGGA' ]] || [[ $gid == '$GLGGA' ]] || [[ $gid == '$GBGGA' ]] || [[ $gid == '$GNGGA' ]]; then
  gpsfound=1 #We recognize these sat systems
 fi
fi

if [ $gpsfound -eq 0 ]; then
 echo File $gpsinfo does not exist or wrong format, setting gps location to 0s.
 glat="0.0"; gltrf="N"; glon="0.0"; glnrf="E"; galt="0.0"; garf="M"
fi

#Embed the data, which is pointed to by the exif tags we add later.
#defaults: lat 33° 51' 28.26'' N, long. 118° 0' 56.5308'' W. Altitude 23m. Direction 90°
#56.5308 produces 56.52 but portraying more accuracy is misleading.

expandloc $glat #makes output values for latitude
gpsrealnum $ldeg #0x220 GPSLatitude
gpsrealnum $lmin #0x228 lat min
gpsrealnum $lsec #0x230 lat sec

expandloc $glon #longitude
gpsrealnum $ldeg #0x238 GPSLongitude
gpsrealnum $lmin #0x240 lat min
gpsrealnum $lsec #0x248 lat sec.

gpsrealnum $galt #0x250 altitude.

#Cam direction has to be in a different file, it's not part of a the GPS device string.
if [ -f $camdir ]; then
 IFS=","
 read cref cdir < $camdir
else
 echo File $camdir does not exist, setting direction to 0.
 cdir="0.0"; cref="T"
fi

#Output image dir (def 77), and later we embed $gltrf(GPSLatitudeRef), 
#$glnrf(GPSLongitudeRef), $cref(GPSImgDirectionRef) in exif headers.
gpsrealnum $cdir #0x258 gpsimgdirection

#Host computer (fixed, not filled in).  We set it to the router IP address and camera IP address.
#Router is retrievable with ~ $ wget -qO- http://ipecho.net/plain 
#192.208.239.230  Note: ipecho service may not be permanent.  Script would have to be 
#adjusted, this field is not filled in from a file or web page.

#We make: "Router 192.208.239.230, Camera 192.168.86.249",0    <-64 chars max allocated.

#If ipecho.net is unreachable or internet is disconnected, you get this:
# wget -qO- http://ipecho.net/plain, # wget: bad address 'ipecho.net', # echo $?, #1
#But it takes 15 seconds.  We'll try to avoid delays by checking the internet different ways.

igood=0
ouraddr=`/sbin/ifconfig eth0 | grep 'inet addr' | cut -d: -f2 | awk '{print $1}'`
if [ ${#ouraddr} -eq 0 ]; then
 ouraddr="has no IP address" #we get "" if we don't have an address, there's no internet.
else
 if ping -q -c 1 -W 1 8.8.8.8 >/dev/null; then #It'll go for 1 second max, like our delays.
  routeraddr=`wget -qO- http://ipecho.net/plain` #Returns "nnn.nnn.nnn.nnn" = 15 max but as low as 7.
  if [ $? -eq 0 ]; then
   igood=1
  fi
 fi
fi

if [ $igood -eq 0 ]; then
 routeraddr="unavailable" #Can't get the router addr.
fi

hostcomputer="Router $routeraddr, Camera $ouraddr"
hostcomputerlen=${#hostcomputer} #embed in IFD
hostcomputerlen=$((hostcomputerlen+1)) #add a null. 
echo -n -e $hostcomputer\\x00 >> $rawname #0x260, max length 64:  TIFFTAG_HOSTCOMPUTER

docfill=$((64-hostcomputerlen))	
addnulls $docfill

#0x2A0: DocumentName (fixed, not filled in).
docnamelen=30
echo -n -e "HWK1910A sensor 16b raw image"\\x00\\x00\\x00 >> $rawname

#Parse weather info: weatherfile = "t=301.0 h=64 b=1013" 
if [ -f $weatherfile ]; then
 IFS=" "
 read klvn relh mbars < $weatherfile
 klvn=`echo -n $klvn | cut -c3-`
 relh=`echo -n $relh | cut -c3-`
 mbars=`echo -n $mbars | cut -c3-`
else
 echo File $weatherfile does not exist, setting all to 0
 klvn="273.15"; relh=0; mbars=0;  
fi

#Celsius = Kelvin - 273.15.
cels=`awk "BEGIN{print $klvn - 273.15}"`

#0x2C0 AmbientTemperature in degrees C,  SRATIONAL. Tag found on:
#https://sno.phy.queensu.ca/~phil/exiftool/TagNames/EXIF.html
weathernum $cels #output SRATIONAL

#0x2C8 Humidity. RATIONAL. (ambient relative humidity in percent)
weathernum $relh

#0x2D0 Pressure. RATIONAL. (air pressure in mbars)
weathernum $mbars 

#Offset 0x2D8: Starts unused area, just before the IFD. We'll pad it.
sync #flush write que
padcount=`stat -c %s $rawname` #file size
padcount=$((ifd0start-padcount))
addnulls $padcount 

#The IFDs (what's looked at to get the locations of the embedded data we just added).
#They call them "tags".  Here's the general format:  
#TAGID(2),  DataType(2), Count(4), DataOffset(4). If count*type < 4 bytes, data is in the DataOffset field.
#DataTypes:  
#1 = BYTE, 8-bits
#2 = ASCII, 8-bit, NULL-terminated string
#3 = SHORT, 16-bit unsigned integer
#4 = LONG, 32-bit unsigned integer
#5 = RATIONAL, Two 32-bit unsigned integers. P,Q:  value = P/Q, Q!=0
#6 = SBYTE, 8-bit signed integer
#7 = UNDEFINE, 8-bit byte
#8 = SSHORT, 16-bit signed integer
#9 = SLONG, 32-bit signed integer
#10 = SRATIONAL, Two 32-bit signed integers
#11 = FLOAT, 4-byte single-precision IEEE floating-point value
#12 = DOUBLE, 8-byte double-precision IEEE floating-point value 
#
#WARNING! TIFF SPEC SAYS, YOU NEED ASCENDING ORDER FOR THE TAGS.

#whereami "IFD 0" #debug. (last was 0x400) Shows offset in case you do a hexdump to check it.
#First the count of tags in this IFD
echo -n -e `expand_2B $ifdtags` >> $rawname #(Was designed to be at 0x400) Number of tags
# TAGID(2),  DataType(2), Count(4), DataOffset(4). Each is 12 bytes.
#Tag1 NewSubFileType, LONG,count1,  Bits (all off): 0=thumbnail,1=multipage,2=transparency mask
echo -n -e \\xfe\\x00\\x04\\x00\\x01\\x00\\x00\\x00\\x00\\x00\\x00\\x00 >> $rawname 
#Tag2 ImageWidth = 1920	
echo -n -e \\x00\\x01\\x04\\x00\\x01\\x00\\x00\\x00\\x80\\x07\\x00\\x00 >> $rawname	
#...  ImageHeight = 1080 (we drop 8 rows from bottom)
echo -n -e \\x01\\x01\\x04\\x00\\x01\\x00\\x00\\x00\\x38\\x04\\x00\\x00 >> $rawname	
# BitsPerSample, 16, (some say need 8,8,8 for some, but with only 2 shorts, can't do it.	
echo -n -e \\x02\\x01\\x03\\x00\\x01\\x00\\x00\\x00\\x10\\x00\\x00\\x00 >> $rawname	
# Compression. 1=no compression.
echo -n -e \\x03\\x01\\x03\\x00\\x01\\x00\\x00\\x00\\x01\\x00\\x00\\x00 >> $rawname	
# PhotometricInterpretation 2=RGB 0x8023 = CFA (Color Filter Array)		
echo -n -e \\x06\\x01\\x03\\x00\\x01\\x00\\x00\\x00\\x23\\x80\\x00\\x00 >> $rawname	
# FillOrder: TIFF standard highly recommends explicitly setting this to 1.	
echo -n -e \\x0A\\x01\\x03\\x00\\x01\\x00\\x00\\x00\\x01\\x00\\x00\\x00 >> $rawname	
# DocumentName: IP addresses. Fixed loc @0x330, need size
echo -n -e \\x0D\\x01\\x02\\x00`expand_4B $docnamelen`\\xA0\\x02\\x0\\x0 >> $rawname	
# ImageDescription. Like coordinates, field name
echo -n -e \\x0e\\x01\\x02\\x00`expand_4B $descriptionlen`\\x90\\x1\\x0\\x0 >> $rawname
# Make (Manufacturer): Ptr to string "StarDot Technologies",0, len+null=21.
echo -n -e \\x0f\\x01\\x02\\x00`expand_4B $companysize`\\x08\\x00\\x00\\x00 >> $rawname
# Model. Ptr to "NetCamSCI" or whatever it turned out to be
echo -n -e \\x10\\x01\\x02\\x00`expand_4B $modelsize`\\x20\\x00\\x00\\x00 >> $rawname
# StripOffsets. If only one giant strip, start of pixel data.
echo -n -e \\x11\\x01\\x04\\x00\\x01\\x00\\x00\\x00`expand_4B $stripoffsets` >> $rawname
# Orientation. 1=normal,2-8 tell the viewer to rotate it but data is same in file.
echo -n -e \\x12\\x01\\x03\\x00\\x01\\x00\\x00\\x00\\x01\\x00\\x00\\x00 >> $rawname
# SamplesPerPixel. 3=rgb (1=greyscale or palette-colored) Assume 1 if CFA.
echo -n -e \\x15\\x01\\x03\\x00\\x01\\x00\\x00\\x00\\x01\\x00\\x00\\x00 >> $rawname
# RowsPerStrip. Just 1 strip,so 1080 = 0x438
echo -n -e \\x16\\x01\\x04\\x00\\x01\\x00\\x00\\x00\\x38\\x04\\x00\\x00 >> $rawname
# StripByteCounts. 1920*1080*2=0x3F4800
echo -n -e \\x17\\x01\\x04\\x00\\x01\\x00\\x00\\x00\\x00\\x48\\x3f\\x00 >> $rawname
# XResolution. Points to rational number,1 CM / 5.04 microns. 
echo -n -e \\x1a\\x01\\x05\\x00\\x01\\x00\\x00\\x00\\xC0\\x00\\x00\\x00 >> $rawname
# YResolution. We have a separate area, but could in fact share as pixels are square.
echo -n -e \\x1b\\x01\\x05\\x00\\x01\\x00\\x00\\x00\\xC8\\x00\\x00\\x00 >> $rawname 
# PlanarConfiguration. 1=samples stored contig. Unnecessary for CFA,but blackmagic had it.
echo -n -e \\x1C\\x01\\x03\\x00\\x01\\x00\\x00\\x00\\x01\\x00\\x00\\x00 >> $rawname
# ResolutionUnit. 1=none,2=inches,3=cm
echo -n -e \\x28\\x01\\x03\\x00\\x01\\x00\\x00\\x00\\x03\\x00\\x00\\x00 >> $rawname
# Software(Name and version number that create the image)
echo -n -e \\x31\\x01\\x02\\x00`expand_4B $snamelen`\\x80\\x00\\x00\\x00 >> $rawname
# DateTime (we copied theirs and put in our null area,must fill it in at capture.)
echo -n -e \\x32\\x01\\x02\\x00\\x14\\x00\\x00\\x00\\x50\\x00\\x00\\x00 >> $rawname
# Artist (author/scientist). Fill it in at offset 0x100,put the size here. 
echo -n -e \\x3B\\x01\\x02\\x00`expand_4B $authorlen`\\x00\\x01\\x00\\x00 >> $rawname
# TIFFTAG_HOSTCOMPUTER: IP addresses. Location at 0x260, just size $docnamelen
echo -n -e \\x3C\\x01\\x02\\x00`expand_4B $hostcomputerlen`\\x60\\x2\\x0\\x0 >> $rawname
# CFARepeatPatternDim CFA manditory (as in photometricint). 2col*2row Matlab says unknown tag 33421
echo -n -e \\x8d\\x82\\x03\\x00\\x02\\x00\\x00\\x00\\x02\\x00\\x02\\x00 >> $rawname
# CFAPattern (Manditory if CFA): 0=r,1=g,2=b: rg gb. Matlab unknown tag 33422
echo -n -e \\x8e\\x82\\x01\\x00\\x04\\x00\\x00\\x00\\x00\\x01\\x01\\x02 >> $rawname
# EXIF ExposureTime dup cause matlab didn't display. Another pgm called this exposuretime,other shutterspeed.
echo -n -e \\x9a\\x82\\x05\\x00\\x01\\x00\\x00\\x00\\x70\\x00\\x00\\x00 >> $rawname
# Pointer to the EXIF IFD (obsolete???)
echo -n -e \\x69\\x87\\x04\\x00\\x01\\x00\\x00\\x00`expand_4B $exifstart` >> $rawname
# Pointer to the GPS IFD
echo -n -e \\x25\\x88\\x04\\x00\\x01\\x00\\x00\\x00`expand_4B $gpsstart` >> $rawname
# TIFF/EPStandardID Manditory in TIFF/EP but fixed as 1,0,0,0. Matlab unknown tag 37398
echo -n -e \\x16\\x92\\x01\\x00\\x04\\x00\\x00\\x00\\x01\\x00\\x00\\x00 >> $rawname
# DNGVersion tag (Required)	1.4.0.0 (blackmagic uses 1.2.0.0)
echo -n -e \\x12\\xc6\\x01\\x00\\x04\\x00\\x00\\x00\\x01\\x04\\x00\\x00 >> $rawname
# DNGBackwardVersion tag (Optional)  Give them 1.2.0.0 in case they can't do 1.4.0.0
echo -n -e \\x13\\xc6\\x01\\x00\\x04\\x00\\x00\\x00\\x01\\x02\\x00\\x00 >> $rawname
# UniqueCameraModel (Required,don't mess with it too much,used by software) 
echo -n -e \\x14\\xc6\\x02\\x00`expand_4B $uniquesize`\\x30\\x00\\x00\\x00 >> $rawname
# CFAPlaneColor Required if non-RGB CFA Images. 0, 1, 2 = r,g,b 
echo -n -e \\x16\\xc6\\x01\\x00\\x03\\x00\\x00\\x00\\x00\\x01\\x02\\x00 >> $rawname
# CFALayout   1=rectangular (no shift in cols or rows)
echo -n -e \\x17\\xc6\\x03\\x00\\x01\\x00\\x00\\x00\\x01\\x00\\x00\\x00 >> $rawname
# BlackLevelRepeatDim.  Rows(2),Cols(2) = 1,1 for it's universal (just subtract it!)
echo -n -e \\x19\\xc6\\x03\\x00\\x02\\x00\\x00\\x00\\x01\\x00\\x01\\x00 >> $rawname
# BlackLevel (Required) If 1x1 matrix and 1 sample per pixel,just the 
echo -n -e \\x1a\\xc6\\x04\\x00\\x01\\x00\\x00\\x00\\${bll}\\${blh}\\x00\\x00 >> $rawname
# WhiteLevel (Required). Blown out value. It works,try 0xFF,0,0,0 and see.
echo -n -e \\x1d\\xc6\\x04\\x00\\x01\\x00\\x00\\x00\\xFF\\xFF\\x00\\x00 >> $rawname
#BaselineNoise is at iso 100, noise=4 for HWK1910A sensor as estimated in ccd_timing
echo -n -e \\x2B\\xC6\\x05\\x00\\x01\\x00\\x00\\x00\\xD0\\x00\\x00\\x00 >> $rawname	
# CameraSerialNumber Ptr to place to store mac address. "0030F4??????",0 len+null=13
echo -n -e \\x2F\\xC6\\x02\\x00\\x0D\\x00\\x00\\x00\\xB0\\x00\\x00\\x00 >> $rawname	
# ActiveArea: top, left, bottom, right. BUT, all examples on net show 0,0,height,width (not height-1),
#  and info on whether it's boundry inclusive is nowhere to be seen on first search pages.
echo -n -e \\x8D\\xC6\\x03\\x00\\x04\\x00\\x00\\x00\\xF8\\x00\\x00\\x00 >> $rawname
#Offset of next IFD or 0 if none.
echo -n -e \\x00\\x00\\x00\\x00 >> $rawname

#WARNING!!! If you add tags, go find "exiftags" variable and the stuff around it and follow instructions.

#These are the EXIF IFD tags.  The IFD format is the same as the regular one but it needs 
#to be pointed to by a tag in the main list.
#http://www.awaresystems.be/imaging/tiff/tifftags/privateifd/exif.html 
#Note this wikipedia: https://en.wikipedia.org/wiki/TIFF/EP
#which states, the TIFF/EP standard puts EXIF tags in IFD0, instead of in a separate 
#IFD as we have here.

#whereami "exif tags" #debug (0x5F2 last seen)
echo -n -e `expand_2B $exiftags` >> $rawname # Number of exif tags.
# ExposureTime using  P,Q = P/Q, Q!=0. Gets called ShutterSpeed if here 
echo -n -e \\x9a\\x82\\x05\\x00\\x01\\x00\\x00\\x00\\x70\\x00\\x00\\x00 >> $rawname
# ExifVersion. Type undefined (8 bits), "0220". 
echo -n -e \\x00\\x90\\x07\\x00\\x04\\x00\\x00\\x00\\x30\\x32\\x32\\x30 >> $rawname 
# The next 3 are read by MatLab as ans.DigitalCamera.UnknownTags 37888-37890
# AmbientTemperature in degrees C, SRATIONAL.
echo -n -e \\x00\\x94\\x0A\\x00\\x01\\x00\\x00\\x00\\xC0\\x02\\x00\\x00 >> $rawname 
# Humidity. RATIONAL. (ambient relative humidity in percent)
echo -n -e \\x01\\x94\\x05\\x00\\x01\\x00\\x00\\x00\\xC8\\x02\\x00\\x00 >> $rawname 
# Pressure. RATIONAL. (air pressure in hPa or mbar)
echo -n -e \\x02\\x94\\x05\\x00\\x01\\x00\\x00\\x00\\xD0\\x02\\x00\\x00 >> $rawname 
# End of exif IFD chain
echo -n -e \\x00\\x00\\x00\\x00 >> $rawname 

#GPS IFD tags: http://www.awaresystems.be/imaging/tiff/tifftags/privateifd/gps.html. 
#Stardot = lat 33.857850, long -118.015703,  helpful info: http://www.geomidpoint.com/latlon.html
#Corrected Stardot coordinates (fill in defaults):  lat 33° 51' 28.26'' N,  long. 118° 0' 56.5308'' W,   
#Alt: 75' = 22.86 (23) meters.  ref: 0=above, 1=below

#whereami "gps tags" #debug (0x634 last seen)
echo -n -e `expand_2B $gpstags` >> $rawname #Number of gps tags.
# GPSVersionID. 2, 2, 0, 0
echo -n -e \\x00\\x00\\x01\\x00\\x04\\x00\\x00\\x00\\x02\\x02\\x00\\x00 >> $rawname 
# GPSLatitudeRef. 'N',0 or 'S',0. lat=-90 to 90.
gltrf=`refcheck $gltrf`
echo -n -e \\x01\\x00\\x02\\x00\\x02\\x00\\x00\\x00${gltrf}\\x00\\x00\\x00 >> $rawname 
# GPSLatitude ptr to 3 rational, deg, min, sec. use 1 for denom.
echo -n -e \\x02\\x00\\x05\\x00\\x03\\x00\\x00\\x00\\x20\\x02\\x00\\x00 >> $rawname 
# GPSLongitudeRef. 'W',0 or 'E',0. long=-180 to 180. 
glnrf=`refcheck $glnrf`
echo -n -e \\x03\\x00\\x02\\x00\\x02\\x00\\x00\\x00${glnrf}\\x00\\x00\\x00 >> $rawname 
# GPSLongitude ptr to 3 rational. deg,min,sec.
echo -n -e \\x04\\x00\\x05\\x00\\x03\\x00\\x00\\x00\\x38\\x02\\x00\\x00 >> $rawname 
# GPSAltitudeRef,1 byte. 0=above sea,1=below. Note: We have garf (alt units), but that's not in tags.
echo -n -e \\x05\\x00\\x01\\x00\\x01\\x00\\x00\\x00\\x00\\x00\\x00\\x00 >> $rawname 
# GPSAltitude ptr to 1 rational. distance in meters.
echo -n -e \\x06\\x00\\x05\\x00\\x01\\x00\\x00\\x00\\x50\\x02\\x00\\x00 >> $rawname 
# GPSImgDirectionRef. T,0 for true,M,0 for magnetic. From a file.
cref=`refcheck $cref`
echo -n -e \\x10\\x00\\x02\\x00\\x02\\x00\\x00\\x00${cref}\\x00\\x00\\x00 >> $rawname 
# GPSImgDirection. ptr to 1 of RATIONAL  0.00 to 359.99. From a file.
echo -n -e \\x11\\x00\\x05\\x00\\x01\\x00\\x00\\x00\\x58\\x02\\x00\\x00 >> $rawname 
# End of gps IFD chain
echo -n -e \\x00\\x00\\x00\\x00 >> $rawname 

#Now copy the "strip data" (raw image) after that. But our capture has 1088 lines.
#The extra lines would be ignored as unknown data, but for the sake of size let's chop
#them off. Each row is 1920*2bytes = 3840. Currently the file size is 0x56A. We're adding 
#the cropped raw file which is 4147200 bytes. Final size will be 4148608 in ls -l listing.  

dd if=$dumpfile ibs=3840 obs=3840 count=1080 1>/dev/null 2>/dev/null >> $rawname
rm -f $dumpfile

#Keep these commented out. It's only for testing.

#dumplength=$((stripoffsets+16)) #dump a row into the actual picture
#hexdump -C -n $dumplength $rawname #debug only

#ls -l /var/tmp 
#rm /var/tmp/*.dng

exit 0 #no error.
