#!/bin/sh

#Manual IR mechanism controller for StarDot i2c based fpga designs (such as NetCamSCI).
#It is recommended to use this instead of the i2c commands, in case something
#changes. Note that this command assumes you have the camera web page control set
#to the default of "off" (IR filter is in place). "on" is also ok (IR filter
#is removed) but exposure will be quite a bit lower if you leave it that way
#and your capture script will need to switch to IR picture first, non-IR second.
#Don't use "auto" or schedule the IR, if you are manipulating it with this script.

#Typical use: Close IR (or assume it was closed from last time), take a 16 bit raw pic. 
#Then open IR, take another pic. End by closing it again.  Note that just before
#starting that 2 pic process, the camera is typically locked into 16 bit raw mode,
#during which time exposure will not change.  Opening the IR is safe however, because
#of the huge dynamic range of that sensor. See script capture_DNG.sh for the full 
#capture logic.

#Use:  ir_control.sh open (or close). 
#open = remove the IR filter. Picture will contain the IR contribution.
#close = replace the IR filter. Picture will be visible light only.

#i2c control commands:
#i2cget -y -f 0 0x21 7 #get current settings: "00"&IR[2]&lowsat[4]
#i2cset -y -f 0 0x21 7 NN #Set IR control reg (7) of stardot chip @ 0x42
#IR[2] = 00=keep closed. 01= keep open (IR mode), 10 = automatic

scriptname=${0##*/} #name of this script for error msg use

#This function will read the current register 07 settings,
#replace the 2 IR control bits with what you specify, and write it back.
#It will display the i2cset or get error code and exit with 1 if there was 
#an  error (typically i2c bus arbitration or loss issues).

setreg7() #setreg7 0 (close) or 1 (open)
{
 lowreg=`i2cget -y -f 0 0x21 7 | cut -c4` #low nibble
 if [ ${#lowreg} -eq 0 ]; then #returns null string if failed
  echo "$scriptname: IR control register not found." >> /var/tmp/log.txt
  exit 1
 fi
 
 fullreg="0x"${1}${lowreg}
 i2cset -y -f 0 0x21 7 $fullreg
 setcode=$?
 if [ $setcode -ne 0 ]; then
  echo "$scriptname: i2cset returned error $setcode." >> /var/tmp/log.txt
  exit 1
 fi
 
 #echo Used $fullreg
 
 exit 0
}

#End of functions, start of actual script

if [ "$#" -eq "1" ]; then
 if [[ $1 == "open" ]]; then
  setreg7 1 #will not return
 fi
 if [[ $1 == "close" ]]; then
  setreg7 0 #will not return
 fi
else
  echo "$scriptname: Script requires a command of 'open' or 'close'."
  exit 1
fi

 
