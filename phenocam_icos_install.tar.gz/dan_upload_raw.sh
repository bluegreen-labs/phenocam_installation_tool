#!/bin/sh (probably was a test program prior to capture_dng.sh)
#test of boot up upload; uploads 2 raw, first with IR closed.
#You MUST Pass the user name and password (typically for admin):
#Call example:   yourscript.sh admin admin

#Exit codes:
#0=success (2 pics uploaded)
#1=can't upload pic 1
#2=can't upload pic 2
#3=incorrect input parameters

set -x          #Set to show line #s. Comment out for normal.
debugmode="yes" #outputs messages if yes
#debugmode="no" #keep no for normal operation.

tempdir=/var/tmp  #our temporary working folder.
mkdir -p $tempdir #This folder likely exists, but make sure.
cd $tempdir       #use the dram, don't wear out flash. /var/tmp most space

uploadfolder="/public_html/PhenoDan" #upload folder on our server

if [ $debugmode = "yes" ]; then
 echo Debug mode active, using verbose FTP.
 vb="-v"	#ftp verbose mode if debugging
else
 vb=""
fi

#FUNCTIONS need the () after the specification, but not when called
#or they fail. Also, dont use "function getEXIF()". No good for our shell.
#Export scope: calling this function is same as inline code.

getEXIF()
{
 i2cset -yf 0 0x21 0x20 1 #buffer sequential bytes of EXIF info. 
 swl=`i2cget -yf 0 0x21 0x20 | cut -b3-4` #low exposure (shut width)
 swh=`i2cget -yf 0 0x21 0x20` #high exposure number of rows
 shutwidth=$swh$swl #Full exposure in ascii hex (e.g. 0x0464)
 rpsl=`i2cget -yf 0 0x21 0x20 | cut -b3-4` #low
 rpsh=`i2cget -yf 0 0x21 0x20` #high 
 rowspersec=$rpsh$rpsl #rows per second in ascii hex (e.g. 0x83D6)
 bll=`i2cget -yf 0 0x21 0x20 | cut -b3-4` #low black level
 blh=`i2cget -yf 0 0x21 0x20` #high 
 blacklev=$blh$bll #blacklevel (pedestal e.g. 0x0048)
}

#Shows EXIF info, after it's gathered. Only in debugmode=yes.
showEXIF()
{
if [ $debugmode = "yes" ]; then
 echo Shutter width ${shutwidth}
 echo Rows per second ${rowspersec}
 echo Black level ${blacklev}
fi
}

#Capture a raw dump (It's not a DNG yet). 
# Returns $rawname= file made, or "none"

getDUMP()
{ 
 echo vcap0_0_0_2 o $tempdir > /proc/videograph/gs/dump #make raw pic
 datetimestring=`date +"%Y_%m_%d_%H%M%S"`
 for i in 1 2 3 #if it goes over 3 secs, abort!
 do
  sleep 1s  #1s should do it for dump, most of the time.
  dumpfile=`ls vcap0_0_0_2* 2>/dev/null`  
  if [ -z "$dumpfile" ]
  then
   echo Extra sleep needed for vcap.
   rawname="none"
  else
   rawname=mycamera_${datetimestring}.dng
   mv $dumpfile $rawname  
   break
  fi
 done
}

# feedback on input parameters
if [ "$#" -ne "2" ]; then
 echo "Script Aborted. Please use:  script.sh username userpass"
 exit 3
fi

#our camera "API" consists of web page requests. Fortunately loopback addr works.
#The main negative with this API is that we currently use wget, which always treats
#the results like a file and writes it to our temp folder.

loopaddr="$1:$2@127.0.0.1" # "admin:admin@127.0.0.1"

#Save old overlay setting, turn off overlay (cant have in raw images)
#The commands used to turn it on and off are special, they dont save
#to config flash and so dont wear out the flash.
#Get Value = http://192.168.86.24/vb.htm?textenable1
#Return: OK textenable1=1
#Set Val = http://admin:admin:192.168.86.24/vb.htm?EnableTextForRaw=0 (off)
#off time: likely less than 2 seconds, but ought to allow a little more.

find . -name vb.htm* -delete  #cleanup...
wget http://$loopaddr/vb.htm?textenable1
overlaystate=`cat vb.htm?textenable1 | grep -o '.\{1\}$'`
find . -name vb.htm* -delete  #wget fetches it into a file...
wget http://$loopaddr/vb.htm?EnableTextForRaw=0 #off
find . -name "vb.*" -delete
sleep 3 #overlay seems to go off in < 2 sec. Play it safe.

#Start of script to upload 2 images, one with IR closed, one open.
#First clean oldd files, save IR state, make open and closed values
find . -name "vcap0_0_0_2*" -delete #delete leftovers
oldreg7=`i2cget -yf 0 0x21 7` #save IR reg contents
irclose=`echo $oldreg7 | sed s/./0/3` #Replace top nibble with IR closed 
iropen=`echo $oldreg7 | sed s/./1/3` #Replace top nibble with IR open bits

#Close IR so it can settle before we lock exposure with raw mode.
i2cset -yf 0 0x21 7 $irclose #IR closed
sleep 1s #needs time to close and adjust exposure. 
#raw mode increases H.264 size and we need time to expand buffers
#if it's the first time this ran. 
i2cset -yf 0 0x21 0x1F 1 #trigger raw mode, lock exposure
sleep 1s #let take effect for sure, might be a few pics

if [ ! -r "./firstupload.txt" ]; then #if we've never run before
 echo Need longer wait for buffers to be established for first raw pic.
 echo "ran first upload" > firstupload.txt #remove startup delay.
 sleep 3s
fi

#grab EXIF info for these pics.  shutwdth,exprows wont change. blklv can. 
getEXIF
showEXIF

#Now make that first pic (with IR closed)
getDUMP

if [ $rawname = "none" ]; then
 echo FAILED to make first raw picture!
 exit 1 #oops. didnt make first pic.
fi
ftpput $vb -u stardot -p "S7arD07&0900" stardot-tech.com ${uploadfolder}/${rawname} ${rawname}
rm ${rawname}

#Now a pic with IR open. We have to fetch the pedestal again.
i2cset -yf 0 0x21 7 $iropen #IR open
sleep 1s
getEXIF
showEXIF
getDUMP

if [ $rawname = "none" ]; then
 echo FAILED to make second raw picture!
 exit 2 #oops. didnt make the second pic
fi
ftpput $vb -u stardot -p "S7arD07&0900" stardot-tech.com ${uploadfolder}/${rawname} ${rawname}
rm ${rawname}

i2cset -yf 0 0x21 7 $oldreg7 #restore IR state.
i2cset -yf 0 0x21 0x1F 2 #end raw mode, release exposure

#restore overlay state
wget http://$loopaddr/vb.htm?EnableTextForRaw=$overlaystate
find . -name "vb.*" -delete

exit 0 #no error.


